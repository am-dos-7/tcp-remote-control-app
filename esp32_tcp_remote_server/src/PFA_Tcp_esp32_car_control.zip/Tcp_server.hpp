#ifndef TCP_SERVER_HPP
#define TCP_SERVER_HPP

/* 
 * Début: 07/05/2021
 * Auteur: Am_Zirée
 * 
 * Implémentation d'un serveur TCP à partir des 'C socket'
 */

#include <Arduino.h>
#include <lwip/sockets.h>
#include <esp_log.h>
#include <string.h>
#include <errno.h>
#include "sdkconfig.h"
#include <pthread.h>
//#include <functional>

class TcpServer
{
public:
    TcpServer();
    ~TcpServer();
    int start(char * address, uint16_t port_number);          // démarrer le serveur à l'addresse et sur le port spécifiés
    int disconnect();       // Se déconnecter de la socket
    int sendData(char *data, uint32_t size);  // Ecrire des données sur la socket
    int readData(char *buffer, uint32_t size);// Lire des données à partir de la socket
    int sendAsByteArray(uint32_t);   // Envoyer un 'Unsigned Integer' comme une suite d'octet, LSB First: pratique pour envoyer la taille d'un message
    void setOnDataFunc(void (*function) (uint8_t)); // Définit la fonction à appeler s'il y a une donnée
    bool isClientConnected();
    void setClientConnected(bool);      // Copie le paramètre dans client.Connected, appelée à la connexion eet à la déconnexion


private:
    /*int setAddress(char *);       // Définir l'adresse de la socket
    void setPortNumber(uint16_t);   // Définir le numéro de port de la socket*/
    static void * sta_fn_accept_thread(void *); // Sera lancée dans un thread qui tourne en boucle et se termine à la connexion d'un client: 'sta' prefix for static
    //void *fn_accept(void );
    void launchAcceptThread();           // Lancera le thread d'écoute

    static void * sta_fn_data_thread(void *);
    //void fn_data(void);
    void launchDataThread();            // Lance le thread d'où seront reçues les données du client
    void (*onDataFn)(uint8_t);
    

private:
     int server_descriptor;   // Descripteur de la socket
     int client_descriptor;
     struct sockaddr_in server_address;
     struct sockaddr_in client_address;
     pthread_t accept_thread;
     pthread_t data_thread;
     socklen_t clientAdressLength;
     bool clientConnected;                       // Indique si un client est connecté: est mis à 1 à une connexion et à 0 à une déconnexion
                                                 // Penser à associer une mutex à cet attribut     
    //static void * fn_data;                     // Fonction à appeler lorsqu'il y a une donnée
    /*socklen_t server_length;
    socklen_t client_length;*/

    //uint16_t port_number;
    //char *address;
};

#endif


/*
 *  NOTES GENERALES
 * L'utilisation des Threads POSIX a exigé de rendre statique la fonction passé au thread à sa création
 * (le C ne reconnait pas le mot-clé this du C++ qui accompagne les classes).
 * Cela entraine dans certains cas la nécessité de rendre également statiques plusieurs autres méthodes 
 * de la classe sinon toutes. Pour contourner ce problème, on peut passer en paramètre à la fonction statique
 * en question, un objet dont on va appeler la méthode non statique à l'intérieur de la fonction statique.
 * De cette manière, la méthode statique va juste servir comme coquille juste pour contouner le problème.
 * 
 */