#include <Arduino.h>

#include "esp_camera.h"
#include <WiFi.h>

#include <lwip/sockets.h>
#include <esp_log.h>
#include <string.h>
#include <errno.h>
#include "sdkconfig.h"
#include "esp_cam_libZ.hpp"
#include <Tcp_server.hpp>

 const char* ssid = "ALPHA224";
 const char* password = "CROYANCE214@@";

//const char* ssid = "UnivCasa";
//const char* password = "";

int sock;
char address[] = "192.168.43.187";
uint16_t port = 50885;
#define WIDTH 320
#define HEIGHT 240

void printData(uint8_t data);

EspCamLib camera;

TcpServer *server;

void setup() {
  Serial.begin(9600);
  Serial.setDebugOutput(true);
  Serial.println();

  camera.begin();

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected");


  Serial.print("Camera Ready at ");
  Serial.print(WiFi.localIP());
  Serial.println();

  server = new TcpServer;
  server->setOnDataFunc(printData);
  server->start("", 50885);
  delay(2000);

  camera_fb_t *pic = NULL; 

  Serial.printf("En attente de connexion d'un client!\n");
  while(!server->isClientConnected());
  camera.setFrameSize(taille::VGA);
  while(1){
    //pic = esp_camera_fb_get();
    camera.getFrame(&pic);
    if(pic != NULL){
          if(server->isClientConnected()){
            server->sendAsByteArray(pic->len);
            server->sendData((char *)pic->buf, pic->len);
            Serial.printf("%u octets envoyés\n", pic->len);
          }
          else
            Serial.printf("Client non connecté!\n");
          
          esp_camera_fb_return(pic);
          //delay(50);
        //}
    }
    //delay(100);
  }
}

void loop() {
  // put your main code here, to run repeatedly:
  delay(10000);
  
}

void printData(uint8_t data){
  Serial.printf("Byte received: %u\n", data);
}